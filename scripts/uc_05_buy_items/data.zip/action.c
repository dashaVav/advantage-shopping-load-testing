Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("_ga_TBPYED8WSW=GS1.1.1710937401.6.1.1710938607.0.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga=GA1.2.195396409.1710188489; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga_56EMNRF2S2=GS1.2.1710937950.6.1.1710938374.24.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_gid=GA1.2.1959558917.1710937946; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("userCart=%7B%22userId%22%3A-1%2C%22productsInCart%22%3A%5B%5D%7D; DOMAIN=www.advantageonlineshopping.com");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_cookie("_gid=GA1.2.1943730995.1710929279; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga=GA1.2.380860569.1708628659; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga_56EMNRF2S2=GS1.2.1710936117.12.1.1710936119.58.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga_TBPYED8WSW=GS1.1.1710936116.14.1.1710937506.0.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_url("www.advantageonlineshopping.com", 
		"URL=https://www.advantageonlineshopping.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/services.properties", ENDITEM, 
		"Url=/css/fonts/roboto_regular_macroman/Roboto-Regular-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_light_macroman/Roboto-Light-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/vendor/requirejs/require.js", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_url("ALL", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/DemoAppConfig/parameters/by_tool/ALL", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/roboto_medium_macroman/Roboto-Medium-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	web_add_cookie("_ga_TBPYED8WSW=GS1.1.1710937401.6.1.1710938688.0.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_ga=GA1.1.195396409.1710188489; DOMAIN=www.advantageonlineshopping.com");

	web_add_cookie("_gat=1; DOMAIN=www.advantageonlineshopping.com");

	web_add_header("Origin", 
		"https://www.advantageonlineshopping.com");

	web_add_header("SOAPAction", 
		"com.advantage.online.store.accountserviceGetAccountConfigurationRequest");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("GetAccountConfigurationRequest", 
		"URL=https://www.advantageonlineshopping.com/accountservice/ws/GetAccountConfigurationRequest", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountConfigurationRequest xmlns=\"com.advantage.online.store.accountservice\"></GetAccountConfigurationRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_add_cookie("_ga_56EMNRF2S2=GS1.2.1710937950.6.1.1710938704.60.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_url("categories", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/categories", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("search", 
		"URL=https://www.advantageonlineshopping.com/catalog/api/v1/deals/search?dealOfTheDay=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("popularProducts.json", 
		"URL=https://www.advantageonlineshopping.com/app/tempFiles/popularProducts.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_ga_56EMNRF2S2=GS1.2.1710937950.6.1.1710938734.30.0.0; DOMAIN=www.advantageonlineshopping.com");

	web_url("home-page.html", 
		"URL=https://www.advantageonlineshopping.com/app/views/home-page.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.advantageonlineshopping.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/roboto_thin_macroman/Roboto-Thin-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_bold_macroman/Roboto-Bold-webfont.woff", "Referer=https://www.advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	lr_start_transaction("login");

	lr_end_transaction("login",LR_AUTO);

	web_add_cookie("_octo=GH1.1.985325878.1681745940; DOMAIN=api.github.com");

	web_add_cookie("logged_in=yes; DOMAIN=api.github.com");

	web_add_cookie("dotcom_user=dashaVav; DOMAIN=api.github.com");

	web_add_cookie("fileTreeExpanded=true; DOMAIN=api.github.com");

	web_add_cookie("color_mode=%7B%22color_mode%22%3A%22auto%22%2C%22light_theme%22%3A%7B%22name%22%3A%22light%22%2C%22color_mode%22%3A%22light%22%7D%2C%22dark_theme%22%3A%7B%22name%22%3A%22dark%22%2C%22color_mode%22%3A%22dark%22%7D%7D; DOMAIN=api.github.com");

	web_add_cookie("preferred_color_mode=dark; DOMAIN=api.github.com");

	web_add_cookie("tz=Europe%2FMoscow; DOMAIN=api.github.com");

	web_add_auto_header("Origin", 
		"https://github.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("sec-ch-ua", 
		"\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"YaBrowser\";v=\"24.1\", \"Yowser\";v=\"2.5\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("stats", 
		"URL=https://api.github.com/_private/browser/stats", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://github.com/dashaVav/loadrunner-webtours/tree/master/Scripts", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"stats\": [{\"webVitalTimings\":[{\"name\":\"https://github.com/dashaVav/loadrunner-webtours/tree/master/Scripts\",\"app\":\"react-code-view\",\"inp\":0,\"networkConnType\":\"4g\",\"ssr\":true,\"lazy\":false,\"alternate\":false}],\"timestamp\":1710938779221,\"loggedIn\":true,\"staff\":false,\"bundler\":\"webpack\"}] }", 
		LAST);

	web_add_cookie("_octo=GH1.1.985325878.1681745940; DOMAIN=collector.github.com");

	web_add_cookie("logged_in=yes; DOMAIN=collector.github.com");

	web_add_cookie("dotcom_user=dashaVav; DOMAIN=collector.github.com");

	web_add_cookie("fileTreeExpanded=true; DOMAIN=collector.github.com");

	web_add_cookie("color_mode=%7B%22color_mode%22%3A%22auto%22%2C%22light_theme%22%3A%7B%22name%22%3A%22light%22%2C%22color_mode%22%3A%22light%22%7D%2C%22dark_theme%22%3A%7B%22name%22%3A%22dark%22%2C%22color_mode%22%3A%22dark%22%7D%7D; DOMAIN=collector.github.com");

	web_add_cookie("preferred_color_mode=dark; DOMAIN=collector.github.com");

	web_add_cookie("tz=Europe%2FMoscow; DOMAIN=collector.github.com");

	web_custom_request("collect", 
		"URL=https://collector.github.com/github/collect", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://github.com/dashaVav/loadrunner-webtours/tree/master/Scripts", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"BodyBinary={\"client_id\":\"985325878.1681745940\",\"events\":[{\"page\":\"https://github.com/dashaVav/loadrunner-webtours/tree/master/Scripts\",\"title\":\"loadrunner-webtours/Scripts at master \\xC2\\xB7 dashaVav/loadrunner-webtours\",\"context\":{\"actor_id\":\"114179854\",\"actor_login\":\"dashaVav\",\"actor_hash\":\"06873588d948244a53baf23aa7d25f589c188624d374a095f5f83e519d3247f8\",\"user_id\":\"114179854\",\"user_login\":\"dashaVav\",\"repository_id\":\"758000557\",\"repository_nwo\":\""
		"dashaVav/loadrunner-webtours\",\"repository_public\":\"true\",\"repository_is_fork\":\"false\",\"repository_network_root_id\":\"758000557\",\"repository_network_root_nwo\":\"dashaVav/loadrunner-webtours\",\"referrer\":\"https://github.com/\",\"request_id\":\"C282:C4369:2C1EF11:2CACB67:65FAD5F1\",\"visitor_id\":\"4231942423594231828\",\"region_edge\":\"fra\",\"region_render\":\"iad\",\"staff\":\"false\",\"react\":\"true\",\"reactApp\":\"\\\\\"react-code-view\\\\\"\",\"reactPartials\":\"[\\\\\""
		"keyboard-shortcuts-dialog\\\\\"]\",\"ssr\":\"true\",\"controller\":\"\\\\\"files\\\\\"\",\"action\":\"\\\\\"disambiguate\\\\\"\",\"routePattern\":\"\\\\\"/:user_id/:repository/tree/*name(/*path)\\\\\"\",\"inp\":\"{\\\\\"name\\\\\":\\\\\"INP\\\\\",\\\\\"value\\\\\":0,\\\\\"element\\\\\":\\\\\"\\\\\"}\"},\"type\":\"web-vital\"}],\"request_context\":{\"referrer\":\"https://github.com/\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 "
		"YaBrowser/24.1.0.0 Safari/537.36\",\"screen_resolution\":\"1536x864\",\"browser_resolution\":\"2232x1074\",\"browser_languages\":\"ru,en\",\"pixel_ratio\":0.8333333730697632,\"timestamp\":1710938779228,\"tz_seconds\":10800}}", 
		LAST);

	lr_start_transaction("login");

	return 0;
}